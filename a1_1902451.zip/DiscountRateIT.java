// --------------------------------------------------------------------
// Assignment (1)
// Written by: (Ali Alnajjar, 1902451)
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
package appdevass1;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alinj
 */
public class DiscountRateIT {

    public DiscountRateIT() {
    }

    /**
     * Test of getServiceDiscountRate method, of class DiscountRate.
     */
    @Test
    public void testGetServiceDiscountRate() {
        System.out.println("getServiceDiscountRate");
        String type = "Gold";
        double expResult = 0.15;
        double result = DiscountRate.getServiceDiscountRate(type);
        assertEquals(expResult, result, 0.15);
    }

    /**
     * Test of getProductDiscountRate method, of class DiscountRate.
     */
    @Test
    public void testGetProductDiscountRate() {
        System.out.println("getProductDiscountRate");
        String type = "Gold";
        double expResult = 0.1;
        double result = DiscountRate.getProductDiscountRate(type);
        assertEquals(expResult, result, 0.1);
    }

}
