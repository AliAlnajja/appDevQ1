// --------------------------------------------------------------------
// Assignment (1)
// Written by: (Ali Alnajjar, 1902451)
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
package appdevass1;

import java.util.Date;

/**
 *
 * @author alinj
 */
public class Main {

    //Testing if everything is working by creating a customer and
    //giving the customer a type and everything to check as well if
    //the discounts are being applied
    public static void main(String[] args) {
        Customer c1 = new Customer("jacob");
        System.out.println(c1.toString());

        Visits v1 = new Visits(c1.getName(), new Date());
        v1.getCustomer().setMemberType("Gold");
        v1.getCustomer().setMember(true);
        System.out.println(v1.toString());

        v1.setProductExpense(4.5);
        v1.setServiceExpense(8.5);
        System.out.println(v1.toString());
        System.out.println("Total expense made by " + v1.getName() + " = " + v1.getTotalExpense());
    }
}
