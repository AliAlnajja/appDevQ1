// --------------------------------------------------------------------
// Assignment (1)
// Written by: (Ali Alnajjar, 1902451)
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
package appdevass1;

import java.util.Date;

/**
 *
 * @author alinj
 */
public class Visits {

    /**
     * fields
     */
    private Customer customer;
    private Date date;
    private double serviceExpense;
    private double productExpense;

    /**
     * Constructor
     *
     * @param name customers name
     * @param date the date
     */
    public Visits(String name, Date date) {
        this.customer = new Customer(name);
        this.date = date;
    }

    //Getters and Setters
    public Customer getCustomer() {
        return customer;
    }

    public String getName() {
        return this.customer.getName();
    }

    public double getServiceExpense() {
        return serviceExpense;
    }

    public void setServiceExpense(double serviceExpense) {
        this.serviceExpense = this.serviceExpense + serviceExpense;
    }

    public double getProductExpense() {
        return productExpense;
    }

    public void setProductExpense(double productExpense) {
        this.productExpense = this.productExpense + productExpense;
    }

    public double getTotalExpense() {
        return (serviceExpense - (serviceExpense * DiscountRate.getServiceDiscountRate(customer.getMemberType())))
                + (productExpense - (productExpense * DiscountRate.getProductDiscountRate(customer.getMemberType())));

    }

    /**
     * toString method to print out the information required
     *
     * @return prints out the information
     */
    @Override
    public String toString() {
        return "Visit{"
                + "customer name=" + customer.getName()
                + ", customer member=" + customer.isMember()
                + ", customer member type=" + customer.getMemberType()
                + ", date=" + date
                + ", serviceExpense=" + serviceExpense
                + ", productExpense=" + productExpense
                + '}';
    }
}
