// --------------------------------------------------------------------
// Assignment (1)
// Written by: (Ali Alnajjar, 1902451)
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
package appdevass1;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alinj
 */
public class Question1IT {

    public Question1IT() {
    }

    /**
     * Test of newLine method, of class Question1.
     */
    @Test
    public void testNewLine() {
        System.out.println("newLine");
        String password = "safjh";
        boolean expResult = false;
        boolean result = Question1.newLine(password);
        assertEquals(expResult, result);
    }

    /**
     * Test of single method, of class Question1.
     */
    @Test
    public void testSingle() {
        System.out.println("single");
        String[] password = {"asa"};
        boolean expResult = false;
        boolean result = Question1.single(password);
        assertEquals(expResult, result);
    }

    /**
     * Test of passwordLength method, of class Question1.
     */
    @Test
    public void testPasswordLength() {
        System.out.println("passwordLength");
        String password = "askjfjk";
        boolean expResult = false;
        boolean result = Question1.passwordLength(password);
        assertEquals(expResult, result);
    }

    /**
     * Test of specialChar method, of class Question1.
     */
    @Test
    public void testSpecialChar() {
        System.out.println("specialChar");
        String password = "jkjkjha";
        boolean expResult = false;
        boolean result = Question1.specialChar(password);
        assertEquals(expResult, result);
    }

    /**
     * Test of upperLetter method, of class Question1.
     */
    @Test
    public void testUpperLetter() {
        System.out.println("upperLetter");
        String password = "sakjdh";
        boolean expResult = false;
        boolean result = Question1.upperLetter(password);
        assertEquals(expResult, result);
    }

    /**
     * Test of lowerLetter method, of class Question1.
     */
    @Test
    public void testLowerLetter() {
        System.out.println("lowerLetter");
        String password = "ASDK";
        boolean expResult = false;
        boolean result = Question1.lowerLetter(password);
        assertEquals(expResult, result);
    }

}
