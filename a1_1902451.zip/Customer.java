// --------------------------------------------------------------------
// Assignment (1)
// Written by: (Ali Alnajjar, 1902451)
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
package appdevass1;

/**
 *
 * @author alinj
 */
public class Customer {

    /**
     * fields
     */
    private String name;
    private boolean member = false;
    private String memberType;

    /**
     * Constructor
     *
     * @param name name of the customer
     */
    public Customer(String name) {
        this.name = name;
    }

    //Getter and Setters
    public String getName() {
        return name;
    }

    public boolean isMember() {
        return member;
    }

    public void setMember(boolean member) {
        this.member = member;
    }

    public String getMemberType() {
        return memberType;
    }

    public void setMemberType(String memberType) {
        this.memberType = memberType;
    }

    /**
     * the toString method for printing out the information
     *
     * @return the string of all the information
     */
    @Override
    public String toString() {
        return "Customer{"
                + "name='" + name + '\''
                + ", member=" + member
                + ", memberType='" + memberType + '\''
                + '}';
    }
}
