// --------------------------------------------------------------------
// Assignment (1)
// Written by: (Ali Alnajjar, 1902451)
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
package appdevass1;

import java.util.Random;

/**
 *
 * @author alinj
 */
public class Question1 {

    public static void main(String[] args) {
        // http://www.gutenberg.org/cache/epub/19033/pg19033.txt
        final String[][][] book = {
            {
                {"ALICE was beginning to get very tired of sitting by her sister on the\n",
                    "bank, and of having nothing to do. Once or twice she had peeped into the\n",
                    "book her sister was reading, but it had no pictures or conversations in\n",
                    "it, \"and what is the use of a book,\" thought Alice, \"without pictures or\n",
                    "conversations?\"\n"},
                {"So she was considering in her OWN mind (as well as she could, for the\n",
                    "day made her feel very sleepy and stupid), whether the pleasure of\n",
                    "making a daisy-chain would be worth the trouble of getting up and\n",
                    "picking the daisies, when suddenly a White Rabbit with pink eyes ran\n",
                    "close by her.\n"},
                {"There was nothing so very remarkable in that, nor did Alice think it so\n",
                    "very much out of the way to hear the Rabbit say to itself, \"Oh dear! Oh\n",
                    "dear! I shall be too late!\" But when the Rabbit actually took a watch\n",
                    "out of its waistcoat-pocket and looked at it and then hurried on, Alice\n",
                    "started to her feet, for it flashed across her mind that she had never\n",
                    "before seen a rabbit with either a waistcoat-pocket, or a watch to take\n",
                    "out of it, and, burning with curiosity, she ran across the field after\n",
                    "it and was just in time to see it pop down a large rabbit-hole, under\n",
                    "the hedge. In another moment, down went Alice after it!"}
            },
            {
                {"\"WHAT a curious feeling!\" said Alice. \"I must be shutting up like a\n",
                    "telescope!\"\n"},
                {"And so it was indeed! She was now only ten inches high, and her face\n",
                    "brightened up at the thought that she was now the right size for going\n",
                    "through the little door into that lovely garden.\n"},
                {"After awhile, finding that nothing more happened, she decided on going\n",
                    "into the garden at once; but, alas for poor Alice! When she got to the\n",
                    "door, she found she had forgotten the little golden key, and when she\n",
                    "went back to the table for it, she found she could not possibly reach\n",
                    "it: she could see it quite plainly through the glass and she tried her\n",
                    "best to climb up one of the legs of the table, but it was too slippery,\n",
                    "and when she had tired herself out with trying, the poor little thing\n",
                    "sat down and cried.\n"},
                {"\"Come, there's no use in crying like that!\" said Alice to herself rather\n",
                    "sharply. \"I advise you to leave off this minute!\" She generally gave\n",
                    "herself very good advice (though she very seldom followed it), and\n",
                    "sometimes she scolded herself so severely as to bring tears into her\n",
                    "eyes.\n"},
                {"Soon her eye fell on a little glass box that was lying under the table:\n",
                    "she opened it and found in it a very small cake, on which the words \"EAT\n",
                    "ME\" were beautifully marked in currants. \"Well, I'll eat it,\" said\n",
                    "Alice, \"and if it makes me grow larger, I CAN reach the key; and if it\n",
                    "makes me grow smaller, I can creep under the door: so either way I'll\n",
                    "get into the garden, and I don't care which happens!\"\n"},
                {"She ate a little bit and said anxiously to herself, \"Which way? Which\n",
                    "way?\" holding her hand on the top of her head to feel which way she was\n",
                    "growing; and she was quite surprised to find that she remained the same\n",
                    "size. So she set to work and very soon finished off the cake."}
            },
            {
                {"The King and Queen of Hearts were seated on their throne when they\n",
                    "arrived, with a great crowd assembled about them--all sorts of little\n",
                    "birds and beasts, as well as the whole pack of cards: the Knave was\n",
                    "standing before them, in chains, with a soldier on each side to guard\n",
                    "him; and near the King was the White Rabbit, with a trumpet in one hand\n",
                    "and a scroll of parchment in the other. In the very middle of the court\n",
                    "was a table, with a large DISH of tarts upon it. \"I wish they'd get the\n",
                    "trial done,\" Alice thought, \"and hand 'round the refreshments!\"\n"},
                {"The judge, by the way, was the King and he wore his crown over his great\n",
                    "wig. \"That's the jury-box,\" thought Alice; \"and those twelve creatures\n",
                    "(some were animals and some were birds) I suppose they are the jurors.\"\n"},
                {"Just then the White Rabbit cried out \"Silence in the court!\"\n"},
                {"\"HERALD! read the accusation!\" said the King."}
            }
        };

        Random rand = new Random(); // the random class
        //initializing the variables needed
        int special = 0;
        int newLines = 0;
        int singles = 0;
        int equal = 0;
        int lengths = 0;
        int upper = 0;
        int lower = 0;
        String password = "";
        String[] passwords = {"", "", ""};
        int generated = 0;

        System.out.println("Welcome to the password generator game!");
        //for loop till the counter reaches 10000, indication for 10000 passwords generated
        for (int i = 0; i < 10000; i++) {
            // do a password, then see if the conditions are met if they are get out of the loop and print the password
            do {
                password = "";
                // to generate 3 words, then make the password and go through the conditions then if good, print the password out
                for (int j = 0; j < 3; j++) {
                    int page = rand.nextInt(book.length);   // generates a random page
                    int paragraph = rand.nextInt(book[page].length);    // generates a random paragraph
                    int line = rand.nextInt(book[page][paragraph].length);  // generates a random line
                    String phrase = book[page][paragraph][line];   // gives a bunch of words from the array of book.
                    String[] words = phrase.split(" ");     // splits the words into a different array essentially the words are separated by a space
                    int wordNumber = rand.nextInt(words.length);    // the random number for the length of the array of words.
                    password += words[wordNumber];
                    passwords[j] = words[wordNumber];
                }
                if (newLine(password)) {
                    newLines++;
                } else if (single(passwords)) {
                    singles++;
                } else if (!passwordLength(password)) {
                    lengths++;
                } else if (!specialChar(password)) {
                    special++;
                } else if (!upperLetter(password)) {
                    upper++;
                } else if (!lowerLetter(password)) {
                    lower++;
                }
            } while (newLine(password) || single(passwords) || !passwordLength(password) || !specialChar(password)
                    || !upperLetter(password) || !lowerLetter(password));
            System.out.printf("Password = %-15s Newline = %-3d Single = %-3d Equal = %-3d Length = %-3d  "
                    + "Upper = %-3d Lower = %-3d Special = %-3d\n", password, newLines, singles, equal, lengths,
                    upper, lower, special);
            generated++;

            special = 0;
            newLines = 0;
            singles = 0;
            equal = 0;
            lengths = 0;
            upper = 0;
            lower = 0;
        }
        System.out.println();
        System.out.println("total password generated: " + generated);
    }

    /**
     * to see if the password contains a newline or not
     *
     * @param password the password generated randomly
     * @return true or false
     */
    public static boolean newLine(String password) {
        if (password.contains("\n")) {
            return true;
        }
        return false;
    }

    /**
     * to see if the word is a single character or not
     *
     * @param password
     * @return true or false
     */
    public static boolean single(String[] password) {
        for (int i = 0; i < password.length; i++) {
            if (password[i].length() == 1) {
                return true;
            }
        }
        return false;
    }

    /**
     * to see if the password is greater than 8 characters and less than 16
     *
     * @param password the password generated randomly
     * @return true or false
     */
    public static boolean passwordLength(String password) {
        if (password.length() >= 8 && password.length() < 16) {
            return true;
        }
        return false;
    }

    /**
     * to see if there are special characters in the password
     *
     * @param password the password generated randomly
     * @return true or false
     */
    public static boolean specialChar(String password) {
        if (password.matches(".+[^a-zA-Z0-9].+")) {
            return true;
        }
        return false;
    }

    /**
     * to see if there is a upper case letter
     *
     * @param password the password generated randomly
     * @return true or false
     */
    public static boolean upperLetter(String password) {
        if (password.matches(".*[A-Z].*")) {
            return true;
        }
        return false;
    }

    /**
     * to see if there is a lower case letter
     *
     * @param password the password generated randomly
     * @return true or false
     */
    public static boolean lowerLetter(String password) {
        if (password.matches(".*[a-z].*")) {
            return true;
        }
        return false;
    }
}
